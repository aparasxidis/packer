#!/usr/bin/env sh
#
# CIS-LBK Remediation function
# ~/CIS-LBK/functions/remediations/package_installed_fix.sh
#
# Name         Date       Description
# -------------------------------------------------------------------
# E. Pinnell   05/29/20   Check that software package is installed

# Determine correct package manager
